# tallervi-IRSO
Proyecto taller VI. Desarrollo de una API con node express, mysql y deployado en heroku. 
Get: https://irso-tallervi.herokuapp.com/alumnos 
